import './admin.css'

export default function Admin(){
  return(
    <div>
      <h1>Pagina ADMIN!</h1>
    </div>
  )
}